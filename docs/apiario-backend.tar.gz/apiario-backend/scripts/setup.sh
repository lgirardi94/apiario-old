#!/usr/bin/env bash
# =========================================================
#  scripts/setup.sh
#  Setup una-tantum del backend:
#   1. verifica prerequisiti (node, npm, psql)
#   2. assicura un .env valido (interattivo SE serve e SE possibile)
#   3. npm install
#   4. crea lo schema del database (sql/schema.sql)
#   5. applica le migration (sql/migrations/*.sql)
#
#  È idempotente: rilanciarlo non rompe nulla (schema e migration
#  usano IF NOT EXISTS; npm install è sicuro da ripetere).
#
#  Uso:
#     ./scripts/setup.sh
# =========================================================

set -euo pipefail
source "$(dirname "${BASH_SOURCE[0]}")/_lib.sh"

ROOT="$(project_root)"
cd "$ROOT"

title "Setup backend — Il Mio Apiario"
info "Cartella progetto: $ROOT"

# ---------------------------------------------------------
# 1) Prerequisiti
# ---------------------------------------------------------
title "1/5 · Verifica prerequisiti"

has_cmd node || die "Node.js non trovato. Installa Node 18+ e riprova."
NODE_MAJOR="$(node -v | sed 's/v\([0-9]*\).*/\1/')"
if [ "$NODE_MAJOR" -lt 18 ]; then
  die "Serve Node 18 o superiore (trovato $(node -v))."
fi
ok "Node $(node -v)"

has_cmd npm || die "npm non trovato."
ok "npm $(npm -v)"

if has_cmd psql; then
  ok "psql presente"
  HAS_PSQL=1
else
  warn "psql non trovato: non potrò creare lo schema automaticamente."
  warn "Potrai farlo dalla console SQL del provider, oppure installa il client PostgreSQL."
  HAS_PSQL=0
fi

# ---------------------------------------------------------
# 2) File .env
# ---------------------------------------------------------
title "2/5 · Configurazione (.env)"

ENV_FILE="$ROOT/.env"
EXAMPLE_FILE="$ROOT/.env.example"

# Carica .env esistente (se c'è) e l'ambiente già presente.
load_env_file "$ENV_FILE"

# Variabili minime indispensabili per il setup del database e l'avvio.
MISSING=()
require_var DATABASE_URL || MISSING+=("DATABASE_URL")
require_var JWT_SECRET    || MISSING+=("JWT_SECRET")
require_var FRONTEND_URL  || MISSING+=("FRONTEND_URL")

if [ "${#MISSING[@]}" -eq 0 ]; then
  ok "Variabili essenziali presenti (DATABASE_URL, JWT_SECRET, FRONTEND_URL)"
else
  warn "Mancano variabili essenziali: ${MISSING[*]}"

  if is_interactive; then
    info "Ti guido nella creazione del file .env (premi invio per i valori di default)."

    # Punto di partenza: copia .env.example se .env non esiste.
    if [ ! -f "$ENV_FILE" ] && [ -f "$EXAMPLE_FILE" ]; then
      cp "$EXAMPLE_FILE" "$ENV_FILE"
      info "Creato .env da .env.example"
      load_env_file "$ENV_FILE"
    fi

    # DATABASE_URL
    if ! require_var DATABASE_URL; then
      printf "  %s\n" "Connection string PostgreSQL (postgresql://utente:password@host:porta/db):"
      read -r _dburl
      [ -n "$_dburl" ] || die "DATABASE_URL è obbligatoria."
      upsert_env "DATABASE_URL" "$_dburl"
      export DATABASE_URL="$_dburl"
    fi

    # JWT_SECRET (offre di generarlo)
    if ! require_var JWT_SECRET; then
      printf "  %s " "Genero automaticamente un JWT_SECRET sicuro? [S/n]:"
      read -r _gen
      if [ "${_gen:-S}" = "n" ] || [ "${_gen:-S}" = "N" ]; then
        printf "  %s\n" "Inserisci il JWT_SECRET:"
        read -r _jwt
      else
        _jwt="$(node -e "console.log(require('crypto').randomBytes(48).toString('hex'))")"
        ok "JWT_SECRET generato."
      fi
      [ -n "$_jwt" ] || die "JWT_SECRET è obbligatorio."
      upsert_env "JWT_SECRET" "$_jwt"
      export JWT_SECRET="$_jwt"
    fi

    # FRONTEND_URL
    if ! require_var FRONTEND_URL; then
      printf "  %s\n" "URL del frontend (es. https://tuonome.github.io/repo) — serve per CORS e link email:"
      read -r _front
      [ -n "$_front" ] || die "FRONTEND_URL è obbligatoria."
      # rimuove eventuale slash finale
      _front="${_front%/}"
      upsert_env "FRONTEND_URL" "$_front"
      export FRONTEND_URL="$_front"
    fi

    ok "File .env aggiornato."
    warn "Ricorda di configurare anche BREVO_API_KEY e EMAIL_FROM per le email (verifica/reset)."
  else
    err "Ambiente non interattivo e variabili mancanti: ${MISSING[*]}"
    err "Impostale come variabili d'ambiente o in un file .env, poi rilancia."
    exit 1
  fi
fi

# ---------------------------------------------------------
# 3) Dipendenze
# ---------------------------------------------------------
title "3/5 · Installazione dipendenze (npm install)"
npm install
ok "Dipendenze installate."

# ---------------------------------------------------------
# 4) Schema del database
# ---------------------------------------------------------
title "4/5 · Creazione schema database"

SCHEMA="$ROOT/sql/schema.sql"
[ -f "$SCHEMA" ] || die "File schema non trovato: $SCHEMA"

if [ "$HAS_PSQL" -eq 1 ]; then
  info "Eseguo schema.sql sul database..."
  if psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$SCHEMA"; then
    ok "Schema creato/aggiornato."
  else
    die "Errore durante la creazione dello schema. Controlla DATABASE_URL e la connettività."
  fi
else
  warn "psql assente: salto la creazione automatica dello schema."
  warn "Esegui manualmente il contenuto di sql/schema.sql sul tuo database"
  warn "(es. dalla console SQL del provider)."
fi

# ---------------------------------------------------------
# 5) Migration
# ---------------------------------------------------------
title "5/5 · Applicazione migration"

MIGR_DIR="$ROOT/sql/migrations"
if [ "$HAS_PSQL" -eq 1 ] && [ -d "$MIGR_DIR" ]; then
  shopt -s nullglob
  migrazioni=("$MIGR_DIR"/*.sql)
  if [ "${#migrazioni[@]}" -eq 0 ]; then
    info "Nessuna migration da applicare."
  else
    for m in "${migrazioni[@]}"; do
      info "Applico migration: $(basename "$m")"
      if psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f "$m"; then
        ok "$(basename "$m") applicata."
      else
        warn "Migration $(basename "$m") ha dato errore (potrebbe essere già applicata)."
      fi
    done
  fi
  shopt -u nullglob
else
  [ "$HAS_PSQL" -eq 0 ] && warn "psql assente: applica le migration manualmente se necessario."
fi

title "Setup completato 🐝"
ok "Il backend è pronto."
info "Avvia con:   npm start        (produzione)"
info "oppure:      npm run dev      (sviluppo, riavvio automatico)"
info "oppure:      ./scripts/run.sh (setup-and-run per sviluppo locale)"
echo
info "Per designare il primo admin (dopo esserti registrato dall'app):"
info "  ./scripts/create-admin.sh"
